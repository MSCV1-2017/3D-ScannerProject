#ifndef KINECTACQUISITION_H
#define KINECTACQUISITION_H
#include <Kinect.h>
#include <stdexcept>
#include <iostream>
#include <thread>
#include <chrono>
#include <opencv2/opencv.hpp>
#include <pcl/io/boost.h>
#include <pcl/io/grabber.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>


class kinectAcquisition
{
public:
    pcl::PointCloud<pcl::PointXYZ> cloud ;
    kinectAcquisition();
    ~kinectAcquisition();
    void run();

private:
    void InitDepthSource();
    void InitColorSource();
    IDepthFrame* WaitForDepthFrame();
    IColorFrame* WaitForColorFrame();
    void ShowDepthFrame();
    void ShowColorFrame();
    template<class Interface>
    inline void SafeRelease(Interface*& ptr_int);

    static const int depth_w_ = 512;
    static const int depth_h_ = 424;
    static const int color_w_ = 1920;
    static const int color_h_ = 1080;

    IKinectSensor* kin_sensor_;
    IDepthFrameReader* depth_frame_reader_;
    IColorFrameReader* color_frame_reader_;
};

#endif // KINECTACQUISITION_H
